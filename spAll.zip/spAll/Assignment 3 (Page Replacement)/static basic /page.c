//1.FIFO
#include<stdio.h>
#define SIZE 3
void fifo() {
	int full=0;//To check whether all frames are filled
	int a[21],n;//To take the input of reference string
	int frame[SIZE];//This is for frames
	static int f=0;
	int repptr=0;//The pointer for the page that needs to be replaced
	int count=0;//For counting number of page faults
	int display() {
		int i;
		printf("\nThe elements in the frame are\n");
		for(i=0;i<full;i++)
			printf("%d\n",frame[i]);
    	}
	int Pagerep(int ele) {
 		int temp;     
 temp=frame[repptr];
 frame[repptr]=ele;
 repptr++;//The pointer moves to the next frame since the current frame became the newest
  if(repptr==SIZE)
 repptr=0;
 return temp;   //Returns the victim page
}
int Pagefault(int ele)
{
if(full!=SIZE)
   frame[full++]=ele;//Untill all the frames fill, there is no call for page replacement
else
printf("The page replaced is %d",Pagerep(ele));//Displaying of victim page
}
int Search(int ele)//This would search and return the flag that tells whether the page is already //present in the frame or not
{
int i,flag;
    flag=0;
    if(full!=0)
    {
    for(i=0;i<full;i++)
    if(ele==frame[i])
 {   flag=1;
    break;
}
}
 return flag;   
}
void f1() {
int n,i;
    FILE *fp;//For taking input from a file
    //Start
    fp=fopen("Input.txt","r");
    printf("The number of elements in the reference string are :");
    fscanf(fp,"%d",&n);
    printf("%d",n);
    for(i=0;i<n;i++)
    fscanf(fp,"%d",&a[i]);
    fclose(fp);
    printf("\nThe elements present in the string are\n");
    for(i=0;i<n;i++)
    printf("%d  ",a[i]);
    printf("\n\n");
    //End
    for(i=0;i<n;i++)
    {
                    if(Search(a[i])!=1)
                    {
			Pagefault(a[i]);
                    display();
                    count++;
                    }
                                        }
                    printf("\nThe number of page faults are %d\n",count);
}
f1();
}

void optimal() {
int full=0;//To check whether all frames are filled
int a[21],n;//To take the input
int frame[SIZE];
static int f=0;
int repptr;
int count=0;
int display()
{int i;
printf("\nThe elements in the frame are\n");
for(i=0;i<full;i++)
printf("%d\n",frame[i]);
  }
int Longestopt()
{
int temp[SIZE]={0};/*This is for checking the occurence of nearest possible future pages, considering no page is nearest in the beginning*/
int c=0;//Counter to break the loop once we get two nearest future pages
int id,i,k,j=SIZE;
id=0;
    for(i=f+1;i<n;i++)//Checking from the current time of use till the end of string for future references
    {  for(k=0;k<j;k++)  //Checking whether a page occurs in future or not
 {   if(a[i]==frame[k])
{if(temp[k]!=1)
{temp[k]=1;
               c++;
}

    break;}}
if(c==2)
break;//Once we get two future pages then we may break
}
id=2;
while(id!=0)
{if(temp[id]==0)//Checking for the page which is not the nearest future reference
break;
    id--;
}
repptr=id;
return repptr;//Returning the replacement pointer with the value of victim page
}
int Pagerep(int ele)
{
 int temp;
 repptr=Longestopt();
 temp=frame[repptr];
 frame[repptr]=ele;
  return temp;   
}
int Pagefault(int ele)
{if(full!=SIZE)
frame[full++]=ele;
else
printf("The page replaced is %d",Pagerep(ele));
}
int Search(int ele)
{int i,flag;
    flag=0;
    if(full!=0)
    {
    for(i=0;i<full;i++)
    if(ele==frame[i])
 {   flag=1;
    break;
}}
 return flag;   
}
void f2()
{int i;
    FILE *fp;
    fp=fopen("Input.txt","r");
    printf("The number of elements in the reference string are :");
    fscanf(fp,"%d",&n);
    printf("%d",n);
    for(i=0;i<n;i++)
    fscanf(fp,"%d",&a[i]);
    printf("\nThe elements present in the string are\n");
    for(i=0;i<n;i++)
    printf("%d  ",a[i]);
    printf("\n\n");
    for(i=0;i<n;i++)
    {f=i;
                    if(Search(a[i])!=1)
                    {Pagefault(a[i]);
                    display();
                    count++;
                    }
                                        }
                    printf("\nThe number of page faults are %d\n",count);
}
f2();
}

void lru() {
int full=0;//To check whether all frames are filled
int a[21],n;//To take the input
int frame[SIZE];
int ctr[SIZE]={0};
static int f=0;//This is a counter that keeps track of current time
int repptr;
int count=0;
int display()
{int i;
printf("\nThe elements in the frame are\n");
for(i=0;i<full;i++)
printf("%d\n",frame[i]);
}
int Longestopt()//Fucntion for discivering the least recently used page using their corresponding counter values
{int i,min;
    min=0;
    for(i=0;i<SIZE;i++)
    if(ctr[min]>ctr[i])
    min=i;
        repptr=min;
return repptr;
}
int Pagerep(int ele)
{
 int temp;
 repptr=Longestopt();//Gets the LRU page from a function
 temp=frame[repptr];
 frame[repptr]=ele;
 ctr[repptr]=f;//When ever a page is brought it's counter is kept as per the current time of use
  return temp;   
}
int Pagefault(int ele)
{if(full!=SIZE)
{ctr[full]=f;//Setting the counter as per current time of use
               frame[full++]=ele;
}
else
printf("The page replaced is %d",Pagerep(ele));
}
int Search(int ele)
{int i,flag;
    flag=0;
    if(full!=0)
    {
    for(i=0;i<full;i++)
    if(ele==frame[i])
 {   flag=1;ctr[i]=f;//If page fault doesn't occur, but the element is referenced, it's counter is set to the current time of use
    break;
}}
 return flag;   
}
void f3()
{int i;
    FILE *fp;
    fp=fopen("Input.txt","r");
    printf("The number of elements in the reference string are :");
    fscanf(fp,"%d",&n);
    printf("%d",n);
    for(i=0;i<n;i++)
    fscanf(fp,"%d",&a[i]);
    printf("\nThe elements present in the string are\n");
    for(i=0;i<n;i++)
    printf("%d  ",a[i]);
    printf("\n\n");
    for(i=0;i<n;i++)
    {f++;//Time of use is incremented
                    if(Search(a[i])!=1)
                    {Pagefault(a[i]);
                    display();
                    count++;
                    }
                    
                    }
                    printf("\nThe number of page faults are %d\n",count);
                 
}
f3();
}



void lfu() {
int full=0;//To check whether all frames are filled
int a[21],n;//To take the input
int frame[SIZE];
int ctr[SIZE]={0};//Counter to know the frequency, intially all have zero frequency of use
int repptr;
int count=0;
int display()
{int i;
printf("\nThe elements in the frame are\n");
for(i=0;i<full;i++)
printf("%d\n",frame[i]);
}
int Longestopt()
{int i,min;
    min=0;
    for(i=0;i<SIZE;i++)//The page with least frequency is selected as victim
    if(ctr[min]>ctr[i])		
    min=i;
        repptr=min;
return repptr;
}
int Pagerep(int ele)
{
 int temp;
 repptr=Longestopt();//The victim page is selected with the help of a function
 temp=frame[repptr];
 frame[repptr]=ele;
 ctr[repptr]=1;//A new page is brought, hence it's counter is set to 1
  return temp;   
}
int Pagefault(int ele)
{if(full!=SIZE)
{ctr[full]++;//The counters will increase initially for all frames till they are full
               frame[full++]=ele;
}
else
printf("The page replaced is %d",Pagerep(ele));
}
int Search(int ele)
{int i,flag;
    flag=0;
    if(full!=0)
    {
    for(i=0;i<full;i++)
    if(ele==frame[i])
 {   flag=1;ctr[i]++;//Whenever a reference is made the counter is incremented
    break;
}}
 return flag;   
}
void f4()
{int i;
    FILE *fp;
    fp=fopen("Input.txt","r");
    printf("The number of elements in the reference string are :");
    fscanf(fp,"%d",&n);
    printf("%d",n);
    for(i=0;i<n;i++)
    fscanf(fp,"%d",&a[i]);
    printf("\nThe elements present in the string are\n");
    for(i=0;i<n;i++)
    printf("%d  ",a[i]);
    printf("\n\n");
    for(i=0;i<n;i++)
    {
                    if(Search(a[i])!=1)
                    {Pagefault(a[i]);
                    display();
                    count++;
                    }
                    }
                    printf("\nThe number of page faults are %d\n",count);

}
f4();
}



void mfu() {
int full=0;//To check whether all frames are filled
int a[21],n;//To take the input
int frame[SIZE];
int ctr[SIZE]={0};
static int f;
int repptr;
int count=0;
int display()
{
int i;
printf("\nThe elements in the frame are\n");
for(i=0;i<full;i++)
printf("%d\n",frame[i]);
      }
int Longestopt()
{int i,max;
    max=0;//The increment of counter value here is same as that for of LFU
    for(i=0;i<SIZE;i++)//The page with maximum frequency is selected
    if(ctr[max]<ctr[i])
    max=i;
        repptr=max;
return repptr;
}
int Pagerep(int ele)
{
 int temp;
 repptr=Longestopt();
 temp=frame[repptr];
 frame[repptr]=ele;
 ctr[repptr]=1;
  return temp;   
}
int Pagefault(int ele)
{
if(full!=SIZE)
{
ctr[full]++;
               frame[full++]=ele;
}
else
printf("The page replaced is %d",Pagerep(ele));
}
int Search(int ele)
{
int i,flag;
    flag=0;
    if(full!=0)
    {
    for(i=0;i<full;i++)
    if(ele==frame[i])
 {   
flag=1;ctr[i]++;
    break;
}
}
 return flag;   
}
void f5()
{
int i;
    FILE *fp;
    fp=fopen("Input.txt","r");
    printf("The number of elements in the reference string are :");
    fscanf(fp,"%d",&n);
    printf("%d",n);
    for(i=0;i<n;i++)
    fscanf(fp,"%d",&a[i]);
    printf("\nThe elements present in the string are\n");
    for(i=0;i<n;i++)
    printf("%d  ",a[i]);
    printf("\n\n");
    for(i=0;i<n;i++)
    {f=i;
                    if(Search(a[i])!=1)
                    {
			Pagefault(a[i]);
                    display();
                    count++;
                    }
                                        }
                    printf("\nThe number of page faults are %d\n",count);

}
f5();
}



void seccha() {
int full=0;//To check whether all frames are filled
int a[21];//To take the input
int ref[SIZE];//This is for reference bits for each frame
int frame[SIZE];
int repptr=0;//Initialised to first frame
int count=0;
int display()
{
int i;
printf("\nThe elements in the frame are\n");
for(i=0;i<full;i++)
printf("%d\n",frame[i]);
 }
int Pagerep(int ele)
{
 int temp;
 /*When ever a page needs to be replaced the repptr moves from page to page checking whether it's reference bit is 0 or not, if it is 0 it
 coomes out of the while loop and if it is one, it gives a second chance setting the reference bit to 0*/
while(ref[repptr]!=0)
{
ref[repptr++]=0;
 if(repptr==SIZE)
 repptr=0;
}                     
 temp=frame[repptr];
 frame[repptr]=ele;
 ref[repptr]=1;//The latest page reference, hence it is set to 1
 return temp;   
}
int Pagefault(int ele)
{
if(full!=SIZE)
{
ref[full]=1;//All the ref bits are set to 1 as each frame is being filled firstly
               frame[full++]=ele;
}
else
printf("The page replaced is %d",Pagerep(ele));
}
int Search(int ele)
{
int i,flag;
    flag=0;
    if(full!=0)
    {
    for(i=0;i<full;i++)
    if(ele==frame[i])
 {   flag=1;ref[i]=1;//When ever page reference occurs, it's rference bit is set to 1
    break;
}
}
 return flag;   
}
void f6()
{
int n,i;
    FILE *fp;
    fp=fopen("Input.txt","r");
    printf("The number of elements in the reference string are :");
    fscanf(fp,"%d",&n);
    printf("%d",n);
    for(i=0;i<n;i++)
    fscanf(fp,"%d",&a[i]);
    printf("\nThe elements present in the string are\n");
    for(i=0;i<n;i++)
    printf("%d  ",a[i]);
    printf("\n\n");
    for(i=0;i<n;i++)
    {
                    if(Search(a[i])!=1)
                    {
			Pagefault(a[i]);
                    display();
                    count++;
                    }
                                        }
                    printf("\nThe number of page faults are %d\n",count);

}
f6();
}




int main()
{
    int choice;
	do {  
		printf("\n\n----------MENU------------\n");
		printf(" 1.FIFO\n 2.OPTIMAL\n 3.LRU\n 4.LFU\n 5.MFU\n 6.SECOND CHAANCE \n ENTER THE CHOICE: \n");
		scanf("%d",&choice);		
		switch(choice) {
			case 1:
				fifo();
				break;
			case 2:
				optimal();
				break;
			case 3:
				lru();
				break;
			case 4:
				lfu();
				break;
			case 5:
				mfu();
				break;
			case 6: 
				seccha();
				break;
			default:
				printf("\n YOU ENTERED WORNG CHOICE\n");
			}
		}
		while(choice!=7);
		return 0;     
	}

